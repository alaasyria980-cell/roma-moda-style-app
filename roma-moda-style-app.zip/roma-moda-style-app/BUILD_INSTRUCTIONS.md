# 📱 تعليمات بناء التطبيق للاندرويد والايفون

هذا الدليل يشرح كيفية بناء وتوزيع تطبيق ROMA MODA STYLE على نظامي الاندرويد والايفون.

---

## 🎯 المميزة الأساسية

✅ **كود واحد لكلا النظامين** - React Native يسمح بتطوير تطبيق واحد يعمل على:
- 🤖 **Android** (جميع الأجهزة)
- 🍎 **iOS** (iPhone و iPad)

---

## 📋 المتطلبات الأساسية

### لكلا النظامين:
```bash
# Node.js و npm
node --version  # يجب أن يكون 16 أو أحدث
npm --version

# Expo CLI
npm install -g expo-cli

# EAS CLI (لبناء التطبيق)
npm install -g eas-cli
```

### للاندرويد فقط:
- Android Studio (اختياري)
- Java Development Kit (JDK)

### للايفون فقط:
- Mac أو جهاز كمبيوتر
- Xcode
- حساب Apple Developer

---

## 🤖 بناء التطبيق للاندرويد

### الطريقة 1: بناء سريع (موصى به)

```bash
# الذهاب إلى مجلد المشروع
cd roma-moda-style-app

# بناء APK للاندرويد
eas build --platform android

# اختر الخيار: "APK"
# سيتم رفع التطبيق وبناؤه في السحابة
```

**النتيجة:**
- ملف `APK` جاهز للتثبيت على أي جهاز اندرويد
- رابط التحميل سيظهر في Terminal

### الطريقة 2: بناء محلي (متقدم)

```bash
# تثبيت Android SDK
# (عبر Android Studio)

# بناء APK محلياً
eas build --platform android --local
```

### تثبيت APK على جهازك:

```bash
# بعد تحميل الملف
adb install app-release.apk
```

---

## 🍎 بناء التطبيق للايفون

### المتطلبات:
- ✅ Mac أو جهاز كمبيوتر
- ✅ Xcode مثبت
- ✅ حساب Apple Developer

### الخطوات:

```bash
# الذهاب إلى مجلد المشروع
cd roma-moda-style-app

# بناء IPA للايفون
eas build --platform ios

# اختر الخيار: "Internal distribution"
# سيتم رفع التطبيق وبناؤه في السحابة
```

**النتيجة:**
- ملف `IPA` جاهز للتثبيت على iPhone
- رابط التحميل سيظهر في Terminal

---

## 🚀 النشر على المتاجر الرسمية

### 📱 نشر على Google Play (الاندرويد)

#### المتطلبات:
- حساب Google Play Developer ($25 مرة واحدة)
- ملف keystore للتوقيع

#### الخطوات:

1. **إنشاء حساب:**
   - اذهب إلى https://play.google.com/console
   - أنشئ حساب جديد
   - ادفع رسم التسجيل ($25)

2. **بناء التطبيق:**
   ```bash
   eas build --platform android --auto-submit
   ```

3. **ملء بيانات التطبيق:**
   - اسم التطبيق
   - الوصف
   - الصور والفيديو
   - سياسة الخصوصية

4. **الموافقة:**
   - عادة 2-3 ساعات

### 🍎 نشر على App Store (الايفون)

#### المتطلبات:
- حساب Apple Developer ($99/سنة)
- شهادة توقيع Apple
- Mac أو جهاز كمبيوتر

#### الخطوات:

1. **إنشاء حساب:**
   - اذهب إلى https://developer.apple.com
   - اشترك في برنامج Apple Developer
   - ادفع $99/سنة

2. **بناء التطبيق:**
   ```bash
   eas build --platform ios --auto-submit
   ```

3. **ملء بيانات التطبيق:**
   - اسم التطبيق
   - الوصف
   - الصور والفيديو
   - سياسة الخصوصية
   - معلومات الاتصال

4. **الموافقة:**
   - عادة 24-48 ساعة

---

## 📦 توزيع بدون متاجر (اختياري)

### توزيع مباشر (APK للاندرويد):

```bash
# بناء APK
eas build --platform android

# تحميل الملف من الرابط المعطى
# شارك الرابط مع المستخدمين
# يمكنهم تثبيته مباشرة
```

### توزيع عبر Expo (سريع للاختبار):

```bash
# نشر على Expo
eas update

# المستخدمون يحملون تطبيق Expo
# ويفتحون التطبيق من داخله
```

---

## 🔧 إعدادات مهمة

### تحديث معلومات التطبيق:

**ملف:** `app.json`

```json
{
  "expo": {
    "name": "ROMA MODA STYLE",
    "slug": "roma-moda-style-app",
    "version": "1.0.0",
    "icon": "./assets/images/icon.png",
    "description": "تطبيق الأحذية والحقائب النسائية الفاخرة",
    "ios": {
      "bundleIdentifier": "com.romamodastyle.app",
      "buildNumber": "1"
    },
    "android": {
      "package": "com.romamodastyle.app",
      "versionCode": 1
    }
  }
}
```

### تحديث الأيقونة:

1. أنشئ صورة 1024x1024 بكسل
2. ضعها في `assets/icon.png`
3. أضفها إلى `app.json`

---

## 📊 جدول المقارنة

| المعيار | الاندرويد | الايفون |
|--------|---------|--------|
| الكود | نفس الكود | نفس الكود |
| المتطلبات | أقل | أكثر |
| التكلفة | $25 مرة واحدة | $99/سنة |
| وقت الموافقة | 2-3 ساعات | 24-48 ساعة |
| الأجهزة المدعومة | جميع الأجهزة | iPhone و iPad |

---

## 🐛 حل المشاكل الشائعة

### المشكلة: البناء فشل

**الحل:**
```bash
# تنظيف المشروع
npm run reset-project

# إعادة تثبيت الحزم
npm install

# محاولة البناء مرة أخرى
eas build --platform android
```

### المشكلة: خطأ في التوقيع

**الحل:**
```bash
# حذف keystore القديم
rm -rf ~/.android/debug.keystore

# بناء جديد
eas build --platform android
```

### المشكلة: لا يعمل على جهازي

**الحل:**
```bash
# تحديث Expo CLI
npm install -g expo-cli@latest

# تحديث EAS CLI
npm install -g eas-cli@latest

# محاولة البناء مرة أخرى
eas build --platform android
```

---

## 📈 خطوات ما بعد النشر

1. **المراقبة:**
   - تابع عدد التحميلات
   - اقرأ التقييمات
   - اجمع ملاحظات المستخدمين

2. **التحديثات:**
   - أصلح الأخطاء
   - أضف ميزات جديدة
   - حدّث الإصدار

3. **التسويق:**
   - شارك على وسائل التواصل
   - اطلب تقييمات إيجابية
   - اجذب مستخدمين جدد

---

## 📞 الدعم والمساعدة

### روابط مهمة:
- **Expo Docs:** https://docs.expo.dev
- **Google Play Console:** https://play.google.com/console
- **App Store Connect:** https://appstoreconnect.apple.com
- **EAS Build:** https://docs.expo.dev/build/introduction

### التواصل:
- البريد: support@romamodastyle.com
- WhatsApp: +966501234567
- Instagram: @romamodastyle

---

## ✅ قائمة التحقق قبل النشر

- [ ] تحديث رقم الإصدار
- [ ] اختبار على جهازين حقيقيين
- [ ] التحقق من الأيقونة والصور
- [ ] قراءة سياسة الخصوصية
- [ ] ملء جميع البيانات المطلوبة
- [ ] اختبار جميع الميزات
- [ ] التأكد من عدم وجود أخطاء

---

**استمتع بنشر تطبيقك على الاندرويد والايفون! 🎉**

*آخر تحديث: فبراير 2026*
