export const Colors = {
  primary: '#D4AF37', // ذهبي فاخر
  primaryLight: '#E6D5B8', // ذهبي فاتح
  primaryDark: '#B8860B', // ذهبي داكن
  white: '#FFFFFF',
  black: '#000000',
  darkGray: '#1A1A1A',
  lightGray: '#F5F5F5',
  mediumGray: '#E0E0E0',
  text: '#333333',
  textLight: '#666666',
  border: '#CCCCCC',
  error: '#E74C3C',
  success: '#27AE60',
  warning: '#F39C12',
  background: '#FAFAFA',
  cardBackground: '#FFFFFF',
};

export const Shadows = {
  small: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  large: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
};
