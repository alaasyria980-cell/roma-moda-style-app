# دليل تخصيص تطبيق ROMA MODA STYLE

مرحباً بك! هذا الدليل يساعدك على تعديل وتخصيص التطبيق حسب احتياجاتك.

## 📋 جدول المحتويات
1. [تغيير الألوان](#تغيير-الألوان)
2. [تحديث المنتجات](#تحديث-المنتجات)
3. [تغيير اللوغو](#تغيير-اللوغو)
4. [تعديل النصوص والعناوين](#تعديل-النصوص-والعناوين)
5. [إضافة ميزات جديدة](#إضافة-ميزات-جديدة)

---

## 🎨 تغيير الألوان

جميع الألوان موجودة في ملف واحد لسهولة التعديل:

**المسار:** `constants/Colors.ts`

### الألوان الرئيسية:
```typescript
export const Colors = {
  primary: '#D4AF37',        // اللون الذهبي الأساسي
  primaryLight: '#E6D5B8',   // ذهبي فاتح
  primaryDark: '#B8860B',    // ذهبي داكن
  white: '#FFFFFF',          // أبيض
  black: '#000000',          // أسود
  // ... الألوان الأخرى
};
```

### كيفية التغيير:
1. افتح ملف `constants/Colors.ts`
2. غيّر قيم الألوان (الأكواد السادسة عشرية)
3. احفظ الملف
4. التطبيق سيتحدث تلقائياً

**مثال:** لتغيير اللون الذهبي إلى أزرق:
```typescript
primary: '#1E90FF',  // أزرق
```

---

## 📦 تحديث المنتجات

جميع بيانات المنتجات موجودة في ملف واحد:

**المسار:** `constants/Products.ts`

### هيكل المنتج:
```typescript
{
  id: '1',                    // معرّف فريد
  name: 'اسم المنتج',
  category: 'shoes' | 'bags', // الفئة
  price: 2499,                // السعر
  originalPrice: 3299,        // السعر الأصلي (اختياري للخصم)
  image: 'رابط الصورة',
  description: 'وصف المنتج',
  rating: 4.8,                // التقييم
  reviews: 156,               // عدد التقييمات
  sizes: ['35', '36', ...],   // الأحجام المتاحة
  colors: ['أسود', 'أبيض'],  // الألوان المتاحة
  inStock: true,              // حالة المخزون
}
```

### كيفية إضافة منتج جديد:
1. افتح ملف `constants/Products.ts`
2. أضف منتج جديد إلى مصفوفة `PRODUCTS`
3. استخدم معرّف فريد (id)
4. أضف صورة (يمكنك استخدام روابط من Unsplash أو موقعك)

**مثال:**
```typescript
{
  id: '13',
  name: 'حذاء جديد فاخر',
  category: 'shoes',
  price: 2999,
  image: 'https://images.unsplash.com/...',
  description: 'وصف جميل للحذاء',
  rating: 4.9,
  reviews: 50,
  sizes: ['35', '36', '37', '38', '39', '40', '41'],
  colors: ['أسود', 'ذهبي'],
  inStock: true,
}
```

---

## 🎯 تغيير اللوغو

اللوغو الحالي موجود في:

**المسار:** `assets/roma-logo.png`

### كيفية تغيير اللوغو:
1. قم بإنشاء لوغو جديد (PNG أو JPG)
2. ضع الملف في مجلد `assets/`
3. عدّل اسم الملف في ملف `components/Header.tsx`:

```typescript
// ابحث عن هذا السطر:
source={require('@/assets/roma-logo.png')}

// غيّره إلى:
source={require('@/assets/your-new-logo.png')}
```

---

## ✏️ تعديل النصوص والعناوين

### تغيير اسم التطبيق:
**المسار:** `app.json`

```json
{
  "expo": {
    "name": "ROMA MODA STYLE",  // اسم التطبيق
    "slug": "roma-moda-style-app"
  }
}
```

### تغيير النصوص في الشاشات:
كل شاشة لها ملف منفصل:

- **الشاشة الرئيسية:** `app/(tabs)/index.tsx`
- **تفاصيل المنتج:** `app/product-details.tsx`
- **السلة:** `app/cart.tsx`
- **المفضلة:** `app/favorites.tsx`
- **الملف الشخصي:** `app/profile.tsx`

ابحث عن النصوص وعدّلها مباشرة.

---

## 🚀 إضافة ميزات جديدة

### إضافة صفحة جديدة:
1. أنشئ ملف جديد في مجلد `app/`
2. استخدم نفس هيكل الملفات الموجودة
3. استخدم `useRouter` للتنقل

### إضافة مكون جديد:
1. أنشئ ملف في مجلد `components/`
2. استخدم React Native Components
3. استخدم الألوان من `constants/Colors.ts`

### مثال - إضافة زر جديد:
```typescript
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Colors } from '@/constants/Colors';

export function MyButton({ onPress, label }) {
  return (
    <TouchableOpacity style={styles.button} onPress={onPress}>
      <Text style={styles.text}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: Colors.primary,
    paddingVertical: 12,
    borderRadius: 8,
  },
  text: {
    color: Colors.white,
    fontWeight: '600',
  },
});
```

---

## 🔧 الأدوات والموارد

### تشغيل التطبيق:
```bash
npm start          # بدء التطوير
npm run web        # فتح على الويب
npm run android    # فتح على Android
npm run ios        # فتح على iOS
```

### التحقق من الأخطاء:
```bash
npm run lint       # التحقق من الأخطاء
```

---

## 📱 هيكل المشروع

```
roma-moda-style-app/
├── app/                    # صفحات التطبيق
│   ├── (tabs)/
│   │   └── index.tsx      # الشاشة الرئيسية
│   ├── product-details.tsx # تفاصيل المنتج
│   ├── cart.tsx           # السلة
│   ├── favorites.tsx      # المفضلة
│   └── profile.tsx        # الملف الشخصي
├── components/            # المكونات المعاد استخدامها
│   ├── Header.tsx
│   ├── ProductCard.tsx
│   └── CategoryFilter.tsx
├── constants/            # الثوابت والبيانات
│   ├── Colors.ts
│   └── Products.ts
├── assets/              # الصور واللوغو
└── package.json         # الحزم والمتطلبات
```

---

## 💡 نصائح مهمة

1. **احفظ دائماً قبل الاختبار** - استخدم `Ctrl+S` أو `Cmd+S`
2. **أعد تحميل التطبيق** - اضغط `r` في terminal بعد التغييرات
3. **استخدم الألوان من Constants** - لا تكتب الألوان مباشرة
4. **اختبر على أجهزة مختلفة** - تأكد من التوافقية
5. **احتفظ بنسخة احتياطية** - قبل تغييرات كبيرة

---

## ❓ أسئلة شائعة

**س: كيف أضيف صورة جديدة للمنتج؟**
ج: استخدم رابط صورة من Unsplash أو رفع الصورة على خادم وأضف الرابط.

**س: كيف أغير عملة السعر؟**
ج: ابحث عن "ر.س" في الملفات وغيّره إلى عملتك.

**س: كيف أضيف دعم لغة جديدة؟**
ج: أنشئ ملف ترجمة وأضف النصوص بلغات مختلفة.

---

## 📞 الدعم والمساعدة

إذا واجهت مشكلة:
1. تحقق من console للأخطاء
2. تأكد من صحة الصيغة (JSON, TypeScript)
3. جرب إعادة تشغيل خادم التطوير

---

**استمتع بتطوير تطبيقك! 🎉**
