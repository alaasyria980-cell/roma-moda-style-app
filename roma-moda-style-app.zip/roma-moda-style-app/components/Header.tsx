import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';

interface HeaderProps {
  title?: string;
  showLogo?: boolean;
  onSearchPress?: () => void;
  onCartPress?: () => void;
  cartCount?: number;
  showBack?: boolean;
  onBackPress?: () => void;
}

export function Header({
  title,
  showLogo = false,
  onSearchPress,
  onCartPress,
  cartCount = 0,
  showBack = false,
  onBackPress,
}: HeaderProps) {
  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {showBack ? (
          <TouchableOpacity onPress={onBackPress} style={styles.backButton}>
            <Ionicons name="chevron-back" size={24} color={Colors.primary} />
          </TouchableOpacity>
        ) : (
          <View style={styles.spacer} />
        )}

        {showLogo ? (
          <Image
            source={require('@/assets/roma-logo.png')}
            style={styles.logo}
          />
        ) : (
          <Text style={styles.title}>{title || 'ROMA MODA STYLE'}</Text>
        )}

        <View style={styles.actions}>
          {onSearchPress && (
            <TouchableOpacity onPress={onSearchPress} style={styles.iconButton}>
              <Ionicons name="search" size={24} color={Colors.primary} />
            </TouchableOpacity>
          )}
          {onCartPress && (
            <TouchableOpacity onPress={onCartPress} style={styles.cartButton}>
              <Ionicons name="bag" size={24} color={Colors.primary} />
              {cartCount > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeText}>{cartCount}</Text>
                </View>
              )}
            </TouchableOpacity>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    paddingTop: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: Colors.mediumGray,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
  },
  backButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  spacer: {
    width: 40,
  },
  logo: {
    width: 80,
    height: 80,
    resizeMode: 'contain',
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.primary,
    flex: 1,
    textAlign: 'center',
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  iconButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cartButton: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: -4,
    backgroundColor: Colors.error,
    borderRadius: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
});
