import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Shadows } from '@/constants/Colors';
import { Product } from '@/constants/Products';

interface ProductCardProps {
  product: Product;
  onPress?: () => void;
  onFavoritePress?: () => void;
  isFavorite?: boolean;
}

export function ProductCard({
  product,
  onPress,
  onFavoritePress,
  isFavorite = false,
}: ProductCardProps) {
  const [favorite, setFavorite] = useState(isFavorite);

  const handleFavorite = () => {
    setFavorite(!favorite);
    onFavoritePress?.();
  };

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <TouchableOpacity style={[styles.container, Shadows.small]} onPress={onPress}>
      {/* صورة المنتج */}
      <View style={styles.imageContainer}>
        <Image source={{ uri: product.image }} style={styles.image} />

        {/* شارة الخصم */}
        {discount > 0 && (
          <View style={styles.discountBadge}>
            <Text style={styles.discountText}>-{discount}%</Text>
          </View>
        )}

        {/* زر المفضلة */}
        <TouchableOpacity
          style={styles.favoriteButton}
          onPress={handleFavorite}
        >
          <Ionicons
            name={favorite ? 'heart' : 'heart-outline'}
            size={24}
            color={favorite ? Colors.error : Colors.white}
          />
        </TouchableOpacity>
      </View>

      {/* معلومات المنتج */}
      <View style={styles.content}>
        <Text style={styles.name} numberOfLines={2}>
          {product.name}
        </Text>

        {/* التقييم */}
        <View style={styles.ratingContainer}>
          <Ionicons name="star" size={14} color={Colors.primary} />
          <Text style={styles.rating}>{product.rating}</Text>
          <Text style={styles.reviews}>({product.reviews})</Text>
        </View>

        {/* السعر */}
        <View style={styles.priceContainer}>
          <Text style={styles.price}>{product.price.toLocaleString()} ر.س</Text>
          {product.originalPrice && (
            <Text style={styles.originalPrice}>
              {product.originalPrice.toLocaleString()} ر.س
            </Text>
          )}
        </View>

        {/* الألوان المتاحة */}
        {product.colors && product.colors.length > 0 && (
          <View style={styles.colorsContainer}>
            {product.colors.slice(0, 3).map((color, index) => (
              <View
                key={index}
                style={[
                  styles.colorDot,
                  {
                    backgroundColor:
                      color === 'أسود'
                        ? '#000'
                        : color === 'أبيض'
                          ? '#FFF'
                          : color === 'ذهبي'
                            ? Colors.primary
                            : color === 'فضي'
                              ? '#C0C0C0'
                              : color === 'بني'
                                ? '#8B4513'
                                : color === 'بيج'
                                  ? '#F5DEB3'
                                  : color === 'أحمر'
                                    ? '#E74C3C'
                                    : color === 'رمادي'
                                      ? '#808080'
                                      : color === 'وردي'
                                        ? '#FFB6C1'
                                        : '#999',
                  },
                ]}
              />
            ))}
            {product.colors.length > 3 && (
              <Text style={styles.moreColors}>+{product.colors.length - 3}</Text>
            )}
          </View>
        )}

        {/* حالة المخزون */}
        <View style={styles.stockContainer}>
          <View
            style={[
              styles.stockIndicator,
              { backgroundColor: product.inStock ? Colors.success : Colors.error },
            ]}
          />
          <Text
            style={[
              styles.stockText,
              { color: product.inStock ? Colors.success : Colors.error },
            ]}
          >
            {product.inStock ? 'متوفر' : 'غير متوفر'}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
  },
  imageContainer: {
    position: 'relative',
    width: '100%',
    aspectRatio: 1,
    backgroundColor: Colors.lightGray,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  discountBadge: {
    position: 'absolute',
    top: 12,
    left: 12,
    backgroundColor: Colors.error,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  discountText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: 'bold',
  },
  favoriteButton: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    padding: 12,
  },
  name: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 6,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    gap: 4,
  },
  rating: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.text,
  },
  reviews: {
    fontSize: 11,
    color: Colors.textLight,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 8,
  },
  price: {
    fontSize: 14,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  originalPrice: {
    fontSize: 12,
    color: Colors.textLight,
    textDecorationLine: 'line-through',
  },
  colorsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  colorDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  moreColors: {
    fontSize: 10,
    color: Colors.textLight,
    marginLeft: 4,
  },
  stockContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  stockIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  stockText: {
    fontSize: 11,
    fontWeight: '500',
  },
});
