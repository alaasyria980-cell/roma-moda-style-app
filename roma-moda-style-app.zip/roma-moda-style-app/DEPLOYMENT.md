# 🚀 دليل النشر والتوزيع

هذا الدليل يساعدك على نشر تطبيق ROMA MODA STYLE على المتاجر الرسمية.

## 📱 النشر على App Store (iOS)

### المتطلبات:
- حساب Apple Developer ($99/سنة)
- Mac أو جهاز كمبيوتر
- Xcode مثبت

### الخطوات:
1. **إنشاء شهادة التوقيع:**
   ```bash
   eas build --platform ios
   ```

2. **بناء التطبيق:**
   ```bash
   eas build --platform ios --auto-submit
   ```

3. **رفع على App Store Connect:**
   - افتح App Store Connect
   - أنشئ تطبيق جديد
   - أرفع الملف المُنشأ

4. **انتظر الموافقة:**
   - عادة 24-48 ساعة

---

## 🤖 النشر على Google Play (Android)

### المتطلبات:
- حساب Google Play Developer ($25 مرة واحدة)
- ملف keystore للتوقيع

### الخطوات:
1. **إنشاء keystore:**
   ```bash
   eas build --platform android
   ```

2. **بناء التطبيق:**
   ```bash
   eas build --platform android --auto-submit
   ```

3. **رفع على Google Play Console:**
   - افتح Google Play Console
   - أنشئ تطبيق جديد
   - أرفع الملف المُنشأ

4. **انتظر الموافقة:**
   - عادة 2-3 ساعات

---

## 🌐 النشر على الويب

### النشر على Vercel:
```bash
# تثبيت Vercel CLI
npm i -g vercel

# نشر التطبيق
vercel
```

### النشر على Netlify:
```bash
# بناء التطبيق
npm run build

# نشر على Netlify
netlify deploy --prod --dir=web-build
```

---

## 📦 بناء التطبيق محلياً

### بناء APK (Android):
```bash
eas build --platform android --local
```

### بناء IPA (iOS):
```bash
eas build --platform ios --local
```

---

## 🔐 الأمان والخصوصية

### قبل النشر:
- [ ] تحديث رقم الإصدار في `app.json`
- [ ] حذف البيانات الحساسة
- [ ] تفعيل HTTPS
- [ ] اختبار على أجهزة حقيقية
- [ ] فحص الأمان

### ملف الخصوصية:
أنشئ ملف `PRIVACY.md` يشرح:
- ما البيانات التي تجمعها
- كيفية استخدام البيانات
- حقوق المستخدم

---

## 📊 المراقبة والتحليل

### إضافة Google Analytics:
```bash
npm install expo-analytics
```

### إضافة Sentry للأخطاء:
```bash
npm install sentry-expo
```

---

## 🔄 التحديثات المستقبلية

### إصدار تحديث جديد:
1. عدّل الكود
2. حدّث رقم الإصدار
3. بناء التطبيق الجديد
4. نشر على المتاجر

```bash
# تحديث الإصدار
npm version patch  # 1.0.0 -> 1.0.1
npm version minor  # 1.0.0 -> 1.1.0
npm version major  # 1.0.0 -> 2.0.0
```

---

## ❓ أسئلة شائعة

**س: كم تكلفة النشر؟**
ج: App Store: $99/سنة، Google Play: $25 مرة واحدة

**س: كم المدة المتوقعة للموافقة؟**
ج: App Store: 24-48 ساعة، Google Play: 2-3 ساعات

**س: هل يمكن نشر التطبيق مجاناً؟**
ج: نعم، يمكنك نشره على الويب مجاناً

---

## 📞 الدعم

للمساعدة في النشر، تواصل مع:
- فريق Expo: https://expo.io/support
- فريق Apple: https://developer.apple.com/support
- فريق Google: https://support.google.com/googleplay

---

**استمتع بنشر تطبيقك! 🎉**
