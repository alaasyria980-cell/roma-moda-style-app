import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Shadows } from '@/constants/Colors';
import { PRODUCTS } from '@/constants/Products';
import { Header } from '@/components/Header';

export default function ProductDetailsScreen() {
  const router = useRouter();
  const { productId } = useLocalSearchParams();
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [isFavorite, setIsFavorite] = useState(false);

  const product = PRODUCTS.find((p) => p.id === productId);

  if (!product) {
    return (
      <View style={styles.container}>
        <Header title="المنتج" showBack onBackPress={() => router.back()} />
        <View style={styles.notFound}>
          <Text style={styles.notFoundText}>المنتج غير موجود</Text>
        </View>
      </View>
    );
  }

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    alert('تم إضافة المنتج إلى السلة');
  };

  return (
    <View style={styles.container}>
      <Header title={product.name} showBack onBackPress={() => router.back()} />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* صورة المنتج */}
        <View style={styles.imageContainer}>
          <Image source={{ uri: product.image }} style={styles.image} />
          {discount > 0 && (
            <View style={styles.discountBadge}>
              <Text style={styles.discountText}>-{discount}%</Text>
            </View>
          )}
          <TouchableOpacity
            style={styles.favoriteButton}
            onPress={() => setIsFavorite(!isFavorite)}
          >
            <Ionicons
              name={isFavorite ? 'heart' : 'heart-outline'}
              size={28}
              color={isFavorite ? Colors.error : Colors.white}
            />
          </TouchableOpacity>
        </View>

        {/* معلومات المنتج الأساسية */}
        <View style={styles.infoSection}>
          <Text style={styles.productName}>{product.name}</Text>

          {/* التقييم */}
          <View style={styles.ratingContainer}>
            <View style={styles.starsContainer}>
              {[...Array(5)].map((_, i) => (
                <Ionicons
                  key={i}
                  name={i < Math.floor(product.rating) ? 'star' : 'star-outline'}
                  size={16}
                  color={Colors.primary}
                />
              ))}
            </View>
            <Text style={styles.rating}>{product.rating}</Text>
            <Text style={styles.reviews}>({product.reviews} تقييم)</Text>
          </View>

          {/* السعر */}
          <View style={styles.priceContainer}>
            <Text style={styles.price}>{product.price.toLocaleString()} ر.س</Text>
            {product.originalPrice && (
              <Text style={styles.originalPrice}>
                {product.originalPrice.toLocaleString()} ر.س
              </Text>
            )}
          </View>

          {/* الوصف */}
          <Text style={styles.description}>{product.description}</Text>
        </View>

        {/* اختيار الحجم */}
        {product.sizes && product.sizes.length > 0 && (
          <View style={styles.optionSection}>
            <Text style={styles.optionTitle}>اختر الحجم</Text>
            <View style={styles.sizesContainer}>
              {product.sizes.map((size) => (
                <TouchableOpacity
                  key={size}
                  style={[
                    styles.sizeButton,
                    selectedSize === size && styles.sizeButtonActive,
                  ]}
                  onPress={() => setSelectedSize(size)}
                >
                  <Text
                    style={[
                      styles.sizeText,
                      selectedSize === size && styles.sizeTextActive,
                    ]}
                  >
                    {size}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* اختيار اللون */}
        {product.colors && product.colors.length > 0 && (
          <View style={styles.optionSection}>
            <Text style={styles.optionTitle}>اختر اللون</Text>
            <View style={styles.colorsContainer}>
              {product.colors.map((color) => (
                <TouchableOpacity
                  key={color}
                  style={[
                    styles.colorButton,
                    selectedColor === color && styles.colorButtonActive,
                  ]}
                  onPress={() => setSelectedColor(color)}
                >
                  <View
                    style={[
                      styles.colorDot,
                      {
                        backgroundColor:
                          color === 'أسود'
                            ? '#000'
                            : color === 'أبيض'
                              ? '#FFF'
                              : color === 'ذهبي'
                                ? Colors.primary
                                : color === 'فضي'
                                  ? '#C0C0C0'
                                  : color === 'بني'
                                    ? '#8B4513'
                                    : color === 'بيج'
                                      ? '#F5DEB3'
                                      : color === 'أحمر'
                                        ? '#E74C3C'
                                        : color === 'رمادي'
                                          ? '#808080'
                                          : color === 'وردي'
                                            ? '#FFB6C1'
                                            : '#999',
                      },
                    ]}
                  />
                  <Text style={styles.colorLabel}>{color}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* كمية المنتج */}
        <View style={styles.optionSection}>
          <Text style={styles.optionTitle}>الكمية</Text>
          <View style={styles.quantityContainer}>
            <TouchableOpacity
              style={styles.quantityButton}
              onPress={() => setQuantity(Math.max(1, quantity - 1))}
            >
              <Ionicons name="remove" size={20} color={Colors.primary} />
            </TouchableOpacity>
            <Text style={styles.quantityText}>{quantity}</Text>
            <TouchableOpacity
              style={styles.quantityButton}
              onPress={() => setQuantity(quantity + 1)}
            >
              <Ionicons name="add" size={20} color={Colors.primary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* معلومات إضافية */}
        <View style={styles.additionalInfo}>
          <View style={styles.infoItem}>
            <Ionicons name="checkmark-circle" size={20} color={Colors.success} />
            <Text style={styles.infoText}>شحن مجاني للطلبات فوق 100 ر.س</Text>
          </View>
          <View style={styles.infoItem}>
            <Ionicons name="shield-checkmark" size={20} color={Colors.success} />
            <Text style={styles.infoText}>ضمان الجودة 100%</Text>
          </View>
          <View style={styles.infoItem}>
            <Ionicons name="swap-horizontal" size={20} color={Colors.success} />
            <Text style={styles.infoText}>إرجاع سهل خلال 30 يوم</Text>
          </View>
        </View>
      </ScrollView>

      {/* زر الشراء */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={[styles.addToCartButton, !product.inStock && styles.buttonDisabled]}
          onPress={handleAddToCart}
          disabled={!product.inStock}
        >
          <Ionicons name="bag-add" size={24} color={Colors.white} />
          <Text style={styles.addToCartText}>
            {product.inStock ? 'أضف إلى السلة' : 'غير متوفر'}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flex: 1,
  },
  imageContainer: {
    position: 'relative',
    width: '100%',
    aspectRatio: 1,
    backgroundColor: Colors.lightGray,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  discountBadge: {
    position: 'absolute',
    top: 16,
    left: 16,
    backgroundColor: Colors.error,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  discountText: {
    color: Colors.white,
    fontSize: 14,
    fontWeight: 'bold',
  },
  favoriteButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoSection: {
    padding: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.mediumGray,
  },
  productName: {
    fontSize: 20,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 8,
  },
  starsContainer: {
    flexDirection: 'row',
    gap: 2,
  },
  rating: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
  },
  reviews: {
    fontSize: 12,
    color: Colors.textLight,
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  price: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  originalPrice: {
    fontSize: 14,
    color: Colors.textLight,
    textDecorationLine: 'line-through',
  },
  description: {
    fontSize: 14,
    color: Colors.textLight,
    lineHeight: 20,
  },
  optionSection: {
    padding: 16,
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.mediumGray,
  },
  optionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 12,
  },
  sizesContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  sizeButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: Colors.mediumGray,
    backgroundColor: Colors.white,
  },
  sizeButtonActive: {
    borderColor: Colors.primary,
    backgroundColor: Colors.primaryLight,
  },
  sizeText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
  },
  sizeTextActive: {
    color: Colors.primary,
  },
  colorsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  colorButton: {
    alignItems: 'center',
    gap: 6,
  },
  colorButtonActive: {},
  colorDot: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 3,
    borderColor: Colors.mediumGray,
  },
  colorLabel: {
    fontSize: 12,
    color: Colors.text,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    backgroundColor: Colors.lightGray,
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    alignSelf: 'flex-start',
  },
  quantityButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  quantityText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.text,
    minWidth: 30,
    textAlign: 'center',
  },
  additionalInfo: {
    padding: 16,
    backgroundColor: Colors.white,
    gap: 12,
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  infoText: {
    fontSize: 13,
    color: Colors.text,
    flex: 1,
  },
  footer: {
    padding: 16,
    backgroundColor: Colors.white,
    borderTopWidth: 1,
    borderTopColor: Colors.mediumGray,
  },
  addToCartButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.primary,
    paddingVertical: 14,
    borderRadius: 12,
    ...Shadows.medium,
  },
  buttonDisabled: {
    backgroundColor: Colors.textLight,
    opacity: 0.6,
  },
  addToCartText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.white,
  },
  notFound: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notFoundText: {
    fontSize: 16,
    color: Colors.textLight,
  },
});
