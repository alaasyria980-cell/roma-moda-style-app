import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  FlatList,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Shadows } from '@/constants/Colors';
import { Header } from '@/components/Header';

interface CartItem {
  id: string;
  name: string;
  price: number;
  image: string;
  quantity: number;
  size?: string;
  color?: string;
}

export default function CartScreen() {
  const router = useRouter();
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: '1',
      name: 'حذاء كلاسيكي ذهبي',
      price: 2499,
      image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=500&h=500&fit=crop',
      quantity: 1,
      size: '38',
      color: 'ذهبي',
    },
    {
      id: '7',
      name: 'حقيبة يد جلدية فاخرة',
      price: 3999,
      image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=500&h=500&fit=crop',
      quantity: 1,
      color: 'أسود',
    },
  ]);

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity === 0) {
      removeItem(id);
    } else {
      setCartItems(
        cartItems.map((item) =>
          item.id === id ? { ...item, quantity: newQuantity } : item
        )
      );
    }
  };

  const removeItem = (id: string) => {
    setCartItems(cartItems.filter((item) => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shippingFee = subtotal > 100 ? 0 : 50;
  const tax = Math.round(subtotal * 0.15);
  const total = subtotal + shippingFee + tax;

  const renderCartItem = ({ item }: { item: CartItem }) => (
    <View style={[styles.cartItem, Shadows.small]}>
      <Image source={{ uri: item.image }} style={styles.itemImage} />

      <View style={styles.itemContent}>
        <Text style={styles.itemName} numberOfLines={2}>
          {item.name}
        </Text>

        {(item.size || item.color) && (
          <View style={styles.itemOptions}>
            {item.size && (
              <Text style={styles.optionText}>الحجم: {item.size}</Text>
            )}
            {item.color && (
              <Text style={styles.optionText}>اللون: {item.color}</Text>
            )}
          </View>
        )}

        <Text style={styles.itemPrice}>
          {(item.price * item.quantity).toLocaleString()} ر.س
        </Text>
      </View>

      <View style={styles.itemActions}>
        <TouchableOpacity
          style={styles.removeButton}
          onPress={() => removeItem(item.id)}
        >
          <Ionicons name="trash" size={18} color={Colors.error} />
        </TouchableOpacity>

        <View style={styles.quantityControl}>
          <TouchableOpacity
            onPress={() => updateQuantity(item.id, item.quantity - 1)}
          >
            <Ionicons name="remove-circle" size={20} color={Colors.primary} />
          </TouchableOpacity>
          <Text style={styles.quantityText}>{item.quantity}</Text>
          <TouchableOpacity
            onPress={() => updateQuantity(item.id, item.quantity + 1)}
          >
            <Ionicons name="add-circle" size={20} color={Colors.primary} />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  if (cartItems.length === 0) {
    return (
      <View style={styles.container}>
        <Header title="السلة" showBack onBackPress={() => router.back()} />
        <View style={styles.emptyContainer}>
          <Ionicons name="bag" size={80} color={Colors.mediumGray} />
          <Text style={styles.emptyTitle}>السلة فارغة</Text>
          <Text style={styles.emptyText}>
            أضف المنتجات المفضلة لديك إلى السلة
          </Text>
          <TouchableOpacity
            style={styles.continueShoppingButton}
            onPress={() => router.back()}
          >
            <Text style={styles.continueShoppingText}>العودة للتسوق</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Header title="السلة" showBack onBackPress={() => router.back()} />

      <FlatList
        data={cartItems}
        keyExtractor={(item) => item.id}
        renderItem={renderCartItem}
        contentContainerStyle={styles.listContent}
        scrollEnabled={true}
      />

      {/* ملخص الطلب */}
      <View style={styles.summaryContainer}>
        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>المجموع الفرعي</Text>
          <Text style={styles.summaryValue}>
            {subtotal.toLocaleString()} ر.س
          </Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>الشحن</Text>
          <Text style={[styles.summaryValue, shippingFee === 0 && styles.freeShipping]}>
            {shippingFee === 0 ? 'مجاني' : `${shippingFee} ر.س`}
          </Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>الضريبة (15%)</Text>
          <Text style={styles.summaryValue}>{tax.toLocaleString()} ر.س</Text>
        </View>

        <View style={[styles.summaryRow, styles.totalRow]}>
          <Text style={styles.totalLabel}>الإجمالي</Text>
          <Text style={styles.totalValue}>
            {total.toLocaleString()} ر.س
          </Text>
        </View>

        {subtotal < 100 && (
          <View style={styles.freeShippingInfo}>
            <Ionicons name="information-circle" size={16} color={Colors.warning} />
            <Text style={styles.freeShippingText}>
              أضف {(100 - subtotal).toLocaleString()} ر.س لتحصل على شحن مجاني
            </Text>
          </View>
        )}

        <TouchableOpacity style={styles.checkoutButton}>
          <Text style={styles.checkoutText}>متابعة الشراء</Text>
          <Ionicons name="arrow-forward" size={20} color={Colors.white} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.continueButton}
          onPress={() => router.back()}
        >
          <Text style={styles.continueText}>متابعة التسوق</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  cartItem: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
  },
  itemImage: {
    width: 100,
    height: 100,
    resizeMode: 'cover',
  },
  itemContent: {
    flex: 1,
    padding: 12,
    justifyContent: 'space-between',
  },
  itemName: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 4,
  },
  itemOptions: {
    gap: 4,
    marginBottom: 4,
  },
  optionText: {
    fontSize: 11,
    color: Colors.textLight,
  },
  itemPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  itemActions: {
    padding: 12,
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 8,
  },
  removeButton: {
    padding: 4,
  },
  quantityControl: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  quantityText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.text,
    minWidth: 20,
    textAlign: 'center',
  },
  summaryContainer: {
    backgroundColor: Colors.white,
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: Colors.mediumGray,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  summaryLabel: {
    fontSize: 13,
    color: Colors.textLight,
  },
  summaryValue: {
    fontSize: 13,
    fontWeight: '500',
    color: Colors.text,
  },
  freeShipping: {
    color: Colors.success,
    fontWeight: '600',
  },
  totalRow: {
    borderTopWidth: 1,
    borderTopColor: Colors.mediumGray,
    paddingTopY: 12,
    marginTopY: 12,
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.text,
  },
  totalValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primary,
  },
  freeShippingInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FFF3CD',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    marginBottom: 12,
  },
  freeShippingText: {
    fontSize: 12,
    color: Colors.warning,
    flex: 1,
  },
  checkoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.primary,
    paddingVertical: 14,
    borderRadius: 12,
    marginBottom: 8,
    ...Shadows.medium,
  },
  checkoutText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.white,
  },
  continueButton: {
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: Colors.primary,
  },
  continueText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.primary,
    textAlign: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: Colors.textLight,
    textAlign: 'center',
    marginBottom: 24,
  },
  continueShoppingButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 12,
  },
  continueShoppingText: {
    color: Colors.white,
    fontWeight: '600',
  },
});
