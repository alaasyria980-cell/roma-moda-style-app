import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Colors } from '@/constants/Colors';
import { PRODUCTS, Product } from '@/constants/Products';
import { Header } from '@/components/Header';
import { ProductCard } from '@/components/ProductCard';

export default function FavoritesScreen() {
  const router = useRouter();
  const [favorites, setFavorites] = useState<Set<string>>(
    new Set(['1', '3', '7', '9'])
  );

  const favoriteProducts = PRODUCTS.filter((p) => favorites.has(p.id));

  const handleRemoveFavorite = (productId: string) => {
    const newFavorites = new Set(favorites);
    newFavorites.delete(productId);
    setFavorites(newFavorites);
  };

  const handleProductPress = (product: Product) => {
    router.push({
      pathname: '/product-details',
      params: { productId: product.id },
    });
  };

  if (favoriteProducts.length === 0) {
    return (
      <View style={styles.container}>
        <Header title="المفضلة" />
        <View style={styles.emptyContainer}>
          <Ionicons name="heart-outline" size={80} color={Colors.mediumGray} />
          <Text style={styles.emptyTitle}>لا توجد منتجات مفضلة</Text>
          <Text style={styles.emptyText}>
            أضف منتجاتك المفضلة لسهولة الوصول إليها
          </Text>
          <TouchableOpacity
            style={styles.browseButton}
            onPress={() => router.push('/')}
          >
            <Text style={styles.browseButtonText}>تصفح المنتجات</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Header title="المفضلة" />

      <FlatList
        data={favoriteProducts}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ProductCard
            product={item}
            onPress={() => handleProductPress(item)}
            onFavoritePress={() => handleRemoveFavorite(item.id)}
            isFavorite={true}
          />
        )}
        contentContainerStyle={styles.listContent}
        scrollEnabled={true}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  listContent: {
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 16,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.text,
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 14,
    color: Colors.textLight,
    textAlign: 'center',
    marginBottom: 24,
  },
  browseButton: {
    backgroundColor: Colors.primary,
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 12,
  },
  browseButtonText: {
    color: Colors.white,
    fontWeight: '600',
  },
});
