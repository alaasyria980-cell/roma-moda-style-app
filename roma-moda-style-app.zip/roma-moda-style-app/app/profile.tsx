import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Shadows } from '@/constants/Colors';
import { Header } from '@/components/Header';

export default function ProfileScreen() {
  const user = {
    name: 'فاطمة أحمد',
    email: 'fatima@example.com',
    phone: '+966501234567',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    joinDate: 'يناير 2024',
  };

  const menuItems = [
    {
      id: '1',
      icon: 'person',
      label: 'تعديل الملف الشخصي',
      description: 'تحديث معلوماتك الشخصية',
    },
    {
      id: '2',
      icon: 'location',
      label: 'عناويني',
      description: 'إدارة عناوين التسليم',
    },
    {
      id: '3',
      icon: 'card',
      label: 'طرق الدفع',
      description: 'إدارة بطاقاتك البنكية',
    },
    {
      id: '4',
      icon: 'document-text',
      label: 'طلباتي',
      description: 'عرض سجل الطلبات',
    },
    {
      id: '5',
      icon: 'notifications',
      label: 'الإشعارات',
      description: 'إعدادات الإشعارات',
    },
    {
      id: '6',
      icon: 'help-circle',
      label: 'المساعدة والدعم',
      description: 'تواصل معنا',
    },
    {
      id: '7',
      icon: 'settings',
      label: 'الإعدادات',
      description: 'إعدادات التطبيق',
    },
  ];

  return (
    <View style={styles.container}>
      <Header title="الملف الشخصي" />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* بطاقة المستخدم */}
        <View style={[styles.profileCard, Shadows.medium]}>
          <Image source={{ uri: user.avatar }} style={styles.avatar} />
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{user.name}</Text>
            <Text style={styles.userEmail}>{user.email}</Text>
            <Text style={styles.joinDate}>عضو منذ {user.joinDate}</Text>
          </View>
          <TouchableOpacity style={styles.editButton}>
            <Ionicons name="pencil" size={20} color={Colors.primary} />
          </TouchableOpacity>
        </View>

        {/* معلومات الاتصال */}
        <View style={styles.contactSection}>
          <View style={styles.contactItem}>
            <Ionicons name="call" size={20} color={Colors.primary} />
            <Text style={styles.contactText}>{user.phone}</Text>
          </View>
          <View style={styles.contactItem}>
            <Ionicons name="mail" size={20} color={Colors.primary} />
            <Text style={styles.contactText}>{user.email}</Text>
          </View>
        </View>

        {/* قائمة الخيارات */}
        <View style={styles.menuSection}>
          {menuItems.map((item) => (
            <TouchableOpacity key={item.id} style={styles.menuItem}>
              <View style={styles.menuItemLeft}>
                <View style={styles.iconContainer}>
                  <Ionicons name={item.icon as any} size={20} color={Colors.primary} />
                </View>
                <View style={styles.menuItemText}>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  <Text style={styles.menuDescription}>{item.description}</Text>
                </View>
              </View>
              <Ionicons name="chevron-forward" size={20} color={Colors.textLight} />
            </TouchableOpacity>
          ))}
        </View>

        {/* زر تسجيل الخروج */}
        <TouchableOpacity style={styles.logoutButton}>
          <Ionicons name="log-out" size={20} color={Colors.error} />
          <Text style={styles.logoutText}>تسجيل الخروج</Text>
        </TouchableOpacity>

        <View style={styles.footer}>
          <Text style={styles.appVersion}>الإصدار 1.0.0</Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  userInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: '700',
    color: Colors.text,
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 13,
    color: Colors.textLight,
    marginBottom: 4,
  },
  joinDate: {
    fontSize: 12,
    color: Colors.textLight,
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.lightGray,
    justifyContent: 'center',
    alignItems: 'center',
  },
  contactSection: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
    gap: 12,
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  contactText: {
    fontSize: 14,
    color: Colors.text,
    flex: 1,
  },
  menuSection: {
    backgroundColor: Colors.white,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 20,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: Colors.mediumGray,
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.lightGray,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuItemText: {
    flex: 1,
  },
  menuLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    marginBottom: 2,
  },
  menuDescription: {
    fontSize: 12,
    color: Colors.textLight,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: Colors.white,
    borderWidth: 2,
    borderColor: Colors.error,
    paddingVertical: 12,
    borderRadius: 12,
    marginBottom: 20,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: '600',
    color: Colors.error,
  },
  footer: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  appVersion: {
    fontSize: 12,
    color: Colors.textLight,
  },
});
